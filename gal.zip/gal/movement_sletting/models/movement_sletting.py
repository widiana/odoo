# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2017  widianajuniar@gmail.com
#    All Rights Reserved.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError

class MovementSletting(models.Model):
    _name = "movement.sletting"
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _order = "name desc"
                                                              
    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('movement.sletting') or 'Error Number!!!'
        return super(MovementSletting, self).create(vals)


    name = fields.Char(string='Number', size=64, required=True, copy=False, default='New',
        readonly=True, states={'draft': [('readonly', False)]})   
    lot_ids = fields.Many2many('stock.production.lot', 'movement_sletting_lot_rel', 'movement_id', 'lot_id', string='Lots', copy=False,
        readonly=True, states={'draft': [('readonly', False)]})      

    user_id = fields.Many2one('res.users', string='User', track_visibility='onchange',
        readonly=True,
        default=lambda self: self.env.user)
    date = fields.Datetime('Date', copy=False, required=True, default=fields.Datetime.now(),
        readonly=True, states={'draft': [('readonly', False)]})

    location_dest_id = fields.Many2one('stock.location',string='Destination Location',domain="[('usage', '!=', 'view')]",
        readonly=True, states={'draft': [('readonly', False)]})
    note = fields.Text(string='Note', translate=True)
    state = fields.Selection([('draft', 'Draf'),
                            ('done','Done')], default='draft', required=True, index=True)


    @api.multi
    def unlink(self):
        if self.state != 'draft':
            raise UserError(_('Data yang bisa dihapus hanya yang berstatus draft !'))
        return super(MovementSletting, self).unlink()

    @api.multi
    def action_validate_movement(self):
        lot_obj = self.env['stock.production.lot']
        move_obj = self.env['stock.move']
        quant_obj = self.env['stock.quant']
        loc_obj = self.env['stock.location']
        slet_obj = self.env['sletting.order']

        data_awal = {'name': _('Movement Sletting : ') + (self.name or ''),
                        'location_dest_id' : self.location_dest_id.id,
                        'date': self.date,
                        'company_id': self.user_id.company_id.id,
                        }

        if not self.lot_ids :
            raise UserError(_('Data hasil sletting tidak boleh kosong !'))

        for lot in self.lot_ids :
            sletting = slet_obj.search([('name','=',lot.ref)],limit=1)
            if not sletting :
                continue
            source_location_id = sletting.location_dest_id.id
            datas = self._generate_moves_lot_param(lot,source_location_id)
            data_awal.update(datas)
            moves = move_obj.sudo().create(data_awal)
            moves.filtered(lambda move: move.state != 'done').action_done()

        return self.write({'state': 'done'})



    def _generate_moves_lot_param(self, lot, source_location_id):
        value = {    
            'origin': lot.name,
            'product_id': lot.product_id.id,
            'product_uom_qty': lot.product_qty_store,
            'product_uom': lot.product_uom_id.id,
            'state': 'confirmed',
            'restrict_lot_id': lot.id,
            'location_id' : source_location_id,}
        return value