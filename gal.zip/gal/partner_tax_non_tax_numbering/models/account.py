# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2017  widianajuniar@gmail.com
#    All Rights Reserved.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import api, fields, models, SUPERUSER_ID, _


class AccountJournal(models.Model):
    _inherit = "account.journal"

    tax_type = fields.Selection([('non_tax', 'Non Tax'),('tax', 'Tax')], string='Tax Type', default='non_tax')


class AccountInvoice(models.Model):
    _inherit = "account.invoice"

    vat_company = fields.Char(string='Tax Company ID',related='company_id.vat',readonly=True)
    vat_invoice = fields.Char(string='Tax Inv Number',size=50)

    @api.model
    def create(self, vals):
        onchanges = {
            '_onchange_partner_id': ['account_id', 'payment_term_id', 'fiscal_position_id', 'partner_bank_id'],
            '_onchange_journal_id': ['currency_id'],
        }
        
        for onchange_method, changed_fields in onchanges.items():
            if any(f not in vals for f in changed_fields):
                invoice = self.new(vals)
                getattr(invoice, onchange_method)()
                for field in changed_fields:
                    if field not in vals and invoice[field]:
                        vals[field] = invoice._fields[field].convert_to_write(invoice[field], invoice)
        if not vals.get('account_id',False):
            raise UserError(_('Configuration error!\nCould not find any account to create the invoice, are you sure you have a chart of account installed?'))

        #import pdb;pdb.set_trace()
        journal = self.env['account.journal']
        partner = self.env['res.partner']
        partner_tax = partner.browse(vals['partner_id'])
        inv_type = str(self._context.get('type', 'out_invoice'))
        company_id = self._context.get('company_id', self.env.user.company_id.id)
        if partner_tax.purchase_tax_id.id or partner_tax.sales_tax_id.id:
            type = 'general'
            if inv_type in ('in_invoice','in_refund'):
                type = 'purchase'
            elif inv_type in ('out_invoice','out_refund'):
                type = 'sale'
            domain = [('type', '=', type), ('company_id', '=', company_id), ('tax_type', '=', 'tax')]
            journal_id = journal.search(domain, limit=1)
            if journal_id :
                vals.update({'journal_id':journal_id.id})
        invoice = super(AccountInvoice, self.with_context(mail_create_nolog=True)).create(vals)

        if any(line.invoice_line_tax_ids for line in invoice.invoice_line_ids) and not invoice.tax_line_ids:
            invoice.compute_taxes()

        return invoice