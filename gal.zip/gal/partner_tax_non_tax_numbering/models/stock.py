# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2017  widianajuniar@gmail.com
#    All Rights Reserved.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import api, fields, models, SUPERUSER_ID, _


class Picking(models.Model):
    _inherit = 'stock.picking'

    @api.model
    def create(self, vals):
        # TDE FIXME: clean that brol
        type_obj = self.env['stock.picking.type']
        partner_obj = self.env['res.partner']
        defaults = self.default_get(['name', 'picking_type_id'])
        type_picking_id = vals.get('picking_type_id', defaults.get('picking_type_id'))
        type_picking = type_obj.browse(type_picking_id)
        if vals.get('name', '/') == '/' and defaults.get('name', '/') == '/' and type_picking_id :
            sequence = False
            if type_picking.code == 'outgoing' and vals.get('partner_id',False):
                if partner_obj.browse(vals.get('partner_id')).sales_tax_id.id :
                    vals['name'] = self.env['ir.sequence'].next_by_code('stock.picking.tax') or '/'
                    sequence = True
            if not sequence :
                vals['name'] = self.env['stock.picking.type'].browse(vals.get('picking_type_id', defaults.get('picking_type_id'))).sequence_id.next_by_id()

        # TDE FIXME: what ?
        # As the on_change in one2many list is WIP, we will overwrite the locations on the stock moves here
        # As it is a create the format will be a list of (0, 0, dict)
        if vals.get('move_lines') and vals.get('location_id') and vals.get('location_dest_id'):
            for move in vals['move_lines']:
                if len(move) == 3:
                    move[2]['location_id'] = vals['location_id']
                    move[2]['location_dest_id'] = vals['location_dest_id']
        return super(Picking, self).create(vals)