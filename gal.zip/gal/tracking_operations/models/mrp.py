  # -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2017  widianajuniar@gmail.com
#    All Rights Reserved.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import api, fields, models, SUPERUSER_ID, _

class AccountInvoice(models.Model):
    _inherit = 'mrp.production'

    def _get_so_ref(self):
        for x in self :
            ref = False
            sale_order_line_id = False
            def_density = 0.00
            if x.origin :
                source = x.origin.split(':')[0]
                # search di SO
                so_exist = self.env['sale.order'].search([('name','=',source)],limit=1)
                if so_exist :
                    ref = so_exist.client_order_ref
                    sol_exist = self.env['sale.order.line'].search([('order_id','=',so_exist.id),('product_id','=',x.product_id.id)],limit=1)
                    if sol_exist :
                        sale_order_line_id = sol_exist.id
            x.order_ref = ref
            x.sale_order_line_id = sale_order_line_id

    sale_order_line_id = fields.Many2one('sale.order.line','Order Line',compute='_get_so_ref')
    def_density = fields.Float(string='Ketebalan (mm)',related='sale_order_line_id.density',store=True) 
    order_ref = fields.Char('Order Ref',compute='_get_so_ref')
    shift_ids = fields.Many2many('resource.calendar', 'resource_calendar_mrp_rel', 'mrp_id', 'resource_id', string='Shift', copy=False)
    workcenter_id = fields.Many2one('mrp.workcenter','Machine',)
    employee_id = fields.Many2one('hr.employee',string="Operator",)
    no_stbj = fields.Char('No STBJ',size=60)