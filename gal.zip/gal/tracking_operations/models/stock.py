  # -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2017  widianajuniar@gmail.com
#    All Rights Reserved.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
import time
from datetime import datetime, timedelta
from dateutil import relativedelta
from odoo import api, fields, models, SUPERUSER_ID, _

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def _get_po_or_so_ref(self):
        #import pdb;pdb.set_trace()
        DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
        for x in self :
            ref = False
            if x.origin :
                # search di PO
                po_exist = self.env['purchase.order'].search([('name','=',x.origin)],limit=1)
                if po_exist :
                    ref = po_exist.partner_ref
                else :
                    so_exist = self.env['sale.order'].search([('name','=',x.origin)],limit=1)
                    if so_exist :
                        ref = so_exist.client_order_ref
            x.order_ref = ref
            if x.min_date :
                min_date = datetime.strptime(x.min_date, DATETIME_FORMAT)
                x.kemarin = str(min_date + relativedelta.relativedelta(days=-1)) # stu hari sebelum schedule date

    order_ref = fields.Char(string='Order Ref',compute='_get_po_or_so_ref') 
    kemarin = fields.Datetime('Schedule Tomorrow',compute='_get_po_or_so_ref',store=True)


class StockMove(models.Model):
    _inherit = 'stock.move'

    shift_ids = fields.Many2many('resource.calendar', 'resource_calendar_stock_move_rel', 'move_id', 'resource_id', string='Shift', copy=False)
    workcenter_id = fields.Many2one('mrp.workcenter','Machine',)
    employee_id = fields.Many2one('hr.employee',string="Operator",)
    no_stbj = fields.Char('No STBJ',size=60)