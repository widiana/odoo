# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2017 widianajuniar@gmail.com
#    All Rights Reserved.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
{
    "name": "Delivery Slip/Order",
    'version': '1.0',
    'category': 'Warehouse',
    'author':  'Treebyte',
    'website': 'www.treebyte.info',
    'license': 'AGPL-3',
    'summary': '',
    "description": """
    * Print Out Delivery Orders PPN dan Non PPN
    * rev. 26 september 2017
    * rev. 30 september 2017 ukuran font 12px
    * rev. 07 oktober 2017 kembali ke 1 lembar karena print pake kertas continous form
    """,
    "depends": [
        "stock",
        "report",
    ],
    "data": [
        "report/delivery_slip_nonppn.xml",
        "report/delivery_slip_ppn.xml",
        "views/stock.xml",
    ],
    'demo': [
    ],
    'test': [
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
}