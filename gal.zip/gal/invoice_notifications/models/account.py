# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2017  widianajuniar@gmail.com
#    All Rights Reserved.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
import math
from datetime import datetime, timedelta
from odoo import api, fields, models, SUPERUSER_ID, _
import logging

_logger = logging.getLogger(__name__)

class AccountInvoice(models.Model):
    _inherit = "account.invoice"

    @api.multi
    def _compute_interval(self):
        for inv in self :
            interval = 0
            if inv.state == 'open' :
                date_due = inv.date_due
                if date_due :
                    date_now = datetime.today().strftime('%Y-%m-%d')
                    #import pdb;pdb.set_trace()
                    # Compute and update the number of days
                    from_dt = datetime.strptime(date_due, '%Y-%m-%d')
                    to_dt = datetime.strptime(date_now, '%Y-%m-%d')
                    timedelta = from_dt-to_dt
                    interval = timedelta.days
            inv.interval_due = interval
            inv.write({'interval_due_store': interval})

    interval_due = fields.Integer(compute='_compute_interval',string='Int Due')
    interval_due_store = fields.Integer(string='Interval Due')

    # cron due date notif
    @api.multi
    def alert_due_date_invoice_open(self):
        #import pdb;pdb.set_trace()
        groups_obj = self.env['res.groups'] 
        today = datetime.today()

        tujuh   = today + timedelta(days=7)
        lima    = today + timedelta(days=5)
        tiga    = today + timedelta(days=3)
        satu    = today + timedelta(days=1)
        nol     = today

        # looping schedule yang didepan
        for hari in [tujuh,lima,tiga,satu,nol]:
            start_date = str(hari.strftime('%Y-%m-%d 00:00:00'))
            end_date = str(hari.strftime('%Y-%m-%d 23:59:59'))
            due_exist = self.env['account.invoice'].sudo().search([('date_due','>=',start_date),('date_due','<=',end_date),('state','=','open')])
            if due_exist :
                list_schedule = '<p>Nomor Invoice / Faktur, Source Document, dan Partner : </p>\n '
                no = 1
                for inv in due_exist :
                    lst = "<br>"+str(no)+". Nomor Invoice / Faktur : " + str(inv.number) +" , Source Document : " + str(inv.origin) + " , Partner : " + str(inv.partner_id.name) + "</br> \n"
                    list_schedule = list_schedule + lst
                    no += 1

                groups_exist = groups_obj.sudo().search([('name','=ilike','Due date notification')],limit=1)
                if groups_exist :
                    for gr in groups_exist.users :
                        body_html = '<p>Hallo '+str(gr.name)+',</p> \n'+'<p>Berikut daftar Invoice / Faktur yang jatuh tempo tanggal '+str(hari)[:10]+'</p> \n \n '+ list_schedule            
                        # create notifikasi ke email
                        mail        = self.env['mail.mail']
                        notif_mail  = mail.create({'subject'    : 'Due Date ('+str(hari)[:10]+')',
                                                'email_from'    : gr.company_id.email,
                                                'email_to'      : gr.partner_id.email,
                                                #'email_cc'     : 
                                                'auto_delete'   : True,
                                                'type'          : 'notification',
                                                'recipient_ids' : [(6, 0, [gr.partner_id.id])],
                                                'notification'  : True,
                                                'body_html'     : body_html,
                                                })
                        _logger.info("created due date invoice alert to %s" % (gr.partner_id.email) )

        # looping schedule yang sudah terlewat
        due_exist2 = self.env['account.invoice'].sudo().search([('date_due','<=',end_date),('state','=','open')])
        if due_exist2 :
            list_schedule = '<p>Nomor Invoice / Faktur, Source Document, dan Partner : </p> '
            no = 1
            for inv in due_exist2 :
                lst = "<br>"+str(no)+". Nomor Invoice / Faktur : " + str(inv.number) +" , Source Document : " + str(inv.origin) +" , Partner : " + str(inv.partner_id.name) + " , Due Date : " + str(inv.date_due)[:10] + "</br> \n"
                list_schedule = list_schedule + lst
                no += 1

            groups_exist = groups_obj.sudo().search([('name','=ilike','Due date notification')],limit=1)
            if groups_exist :
                for gr in groups_exist.users :
                    body_html = '<p>Hallo '+str(gr.name)+',</p> \n'+'<p>Berikut daftar Invoice / Faktur yang sudah jatuh tempo</p> \n \n '+ list_schedule            
                    # create notifikasi ke email
                    mail        = self.env['mail.mail']
                    notif_mail  = mail.create({'subject'    : 'Invoice / Faktur Sudah Jatuh Tempo',
                                            'email_from'    : gr.company_id.email,
                                            'email_to'      : gr.partner_id.email,
                                            #'email_cc'     : 
                                            'auto_delete'   : True,
                                            'type'          : 'notification',
                                            'recipient_ids' : [(6, 0, [gr.partner_id.id])],
                                            'notification'  : True,
                                            'body_html'     : body_html,
                                            })
                    _logger.info("created due date invoice alert to %s" % (gr.partner_id.email) )

        return True