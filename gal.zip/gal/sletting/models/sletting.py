# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2017  widianajuniar@gmail.com
#    All Rights Reserved.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError

class SlettingOrder(models.Model):
    _name = "sletting.order"
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _order = "name desc"
                                                              
    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('sletting.order') or 'Error Number!!!'
        return super(SlettingOrder, self).create(vals)

    @api.one
    @api.depends('lot_id')
    def _product_qty(self):
        self.product_qty = self.lot_id.product_qty_store

    name = fields.Char(string='Number', size=64, required=True, copy=False, default='New',
        readonly=True, states={'draft': [('readonly', False)]})           
    product_id = fields.Many2one('product.product', string="Product", required=True,
        readonly=True, states={'draft': [('readonly', False)]})
    product_id2 = fields.Many2one('product.product', string="Product Hasil", required=True,
        readonly=True, states={'draft': [('readonly', False)]})
    lot_id = fields.Many2one('stock.production.lot',string='Lot',
        readonly=True, states={'draft': [('readonly', False)]},copy=False)
    product_qty = fields.Float(string='Quantity', compute='_product_qty',
        readonly=True,store=True, copy=False)
    product_uom_id = fields.Many2one('product.uom', string="UoM",related='lot_id.product_uom_id', required=True,
        readonly=True, states={'draft': [('readonly', False)]})
    # weight = fields.Float(related='lot_id.weight',string='Weight')
    user_id = fields.Many2one('res.users', string='User', track_visibility='onchange',
        readonly=True,
        default=lambda self: self.env.user)
    date = fields.Datetime('Created Date', copy=False, required=True, default=fields.Datetime.now(),
        readonly=True, states={'draft': [('readonly', False)]})
    schedule_date = fields.Datetime('Schedule Date', copy=False, default=fields.Datetime.now(),
        readonly=True, states={'draft': [('readonly', False)]})
    location_src_id = fields.Many2one('stock.location',string='Source Location',domain="[('usage', '=', 'internal')]",
        readonly=True, states={'draft': [('readonly', False)]})
    location_booking_id = fields.Many2one('stock.location',string='Source Location',domain="[('usage', '=', 'internal')]",
        readonly=True, states={'draft': [('readonly', False)]})
    location_dest_id = fields.Many2one('stock.location',string='Destination Location',domain="[('usage', '=', 'internal')]",
        readonly=True, states={'draft': [('readonly', False)]})
    note = fields.Text(string='Note', translate=True)
    hasil_ids = fields.One2many('sletting.order.hasil','sletting_id',string='Sletting',
        readonly=True, states={'draft': [('readonly', False)],'confirm': [('readonly', False)]})
    resource_id = fields.Many2one('resource.calendar','Shift',readonly=True, states={'draft': [('readonly', False)]})
    workcenter_id = fields.Many2one('mrp.workcenter','Machine',readonly=True, states={'draft': [('readonly', False)]})
    jam = fields.Float('Jam',readonly=True, states={'draft': [('readonly', False)]})
    state = fields.Selection([('draft', 'Draf'),
                            ('confirm', 'Confirmed'),
                            ('cancel', 'Cancelled'),
                            ('done','Done'),
                            ('audit','Audited')], default='draft', required=True, index=True)
    scrap_ids = fields.One2many('stock.scrap', 'sletting_id')
    scrap_count = fields.Integer(compute='_compute_scrap_move_count', string='Scrap Move')
    employee_id = fields.Many2one('hr.employee',string="Operator",readonly=True, states={'draft': [('readonly', False)]})

    @api.onchange('product_id')
    def onchange_product_id(self):
        if self.product_id.id:
            prod = self.env['product.product'].sudo().search([('name','ilike','SFG '+self.product_id.name)],limit=1)
            if prod :
                self.product_id2 = prod.id
            lots = self.env['stock.production.lot'].sudo().search([('product_id','=',self.product_id.id),('product_qty','>',0)])
            if lots :
                for lot in lots :
                    loc_ids = lot.quant_ids.filtered(lambda x: x.location_id.usage == 'internal').mapped('qty')
                    lot.sudo().write({'product_qty_store':sum(loc_ids)})
    # @api.one
    # @api.returns('self', lambda value: value.id)
    # def copy(self, default=None):
    #     default = dict(default or {})
    #     default.update(code=_("%s (copy)") % (self.name or ''))
    #     return super(SlettingOrder, self).copy(default)

    @api.multi
    def _compute_scrap_move_count(self):
        data = self.env['stock.scrap'].read_group([('sletting_id', '=', self.id)], ['sletting_id'], ['sletting_id'])
        count_data = dict((item['sletting_id'][0], item['sletting_id_count']) for item in data)
        for sletting in self:
            sletting.scrap_count = count_data.get(sletting.id, 0)

    @api.multi
    def unlink(self):
        if self.state != 'draft':
            raise UserError(_('Data yang bisa dihapus hanya yang berstatus draft !'))
        return super(SlettingOrder, self).unlink()

    @api.multi
    def action_confirm(self):
        lot_obj = self.env['stock.production.lot']
        move_obj = self.env['stock.move']
        quant_obj = self.env['stock.quant']
        loc_obj = self.env['stock.location']

        self._cr.execute("SELECT SUM(weight) AS qty FROM sletting_order_hasil \
            WHERE sletting_id = %s " , (self.id,))
        total_weight = self._cr.fetchone()[0] or 0.0
        if total_weight > self.product_qty :
            gap = total_weight - self.product_qty
            raise UserError(_('Berat total hasil sletting lebih besar dari berat bahan baku ! (selisih %s)') % (str(gap)))

        datas = self._generate_moves_param()

        product_awal = {'location_id' : self.location_src_id.id,
                        'location_dest_id' : self.product_id.property_stock_production.id,
                        'product_uom_qty' : self.product_qty,
                        'product_uom': self.product_uom_id.id,
                        'restrict_lot_id': self.lot_id.id}

        data1 = datas
        data2 = datas
        data1.update(product_awal)
        # create move raw ke virtual
        move1 = move_obj.sudo().create(data1)
        domain = [('qty', '>', 0.0),('location_id', '=', self.location_src_id.id)]
        preferred_domain_list = [[('reservation_id', '=', False)]]
        quants = quant_obj.quants_get_preferred_domain(move1.product_qty, move1, domain=domain, preferred_domain_list=preferred_domain_list)
        quant_obj.quants_reserve(quants, move1)

        move1.filtered(lambda move: move.state != 'done').action_done()
        self.lot_id.product_qty

        return self.write({'state': 'confirm'})

        ##################################################################################
        # Fitur pembuatan lot grouping per weight dan widht di bypass dulu
        ##################################################################################
        # self._cr.execute("SELECT width,weight,COUNT(id) FROM sletting_order_hasil " \
        #             "WHERE sletting_id = %s " \
        #             "GROUP BY width,weight ", (self.id ,))
        # hasil_grouping = self._cr.fetchall() 

        # for hasil in hasil_grouping:
        #     lot_id = lot_obj.sudo().create({'product_id'        : self.product_id.id,
        #                                     'product_uom_id'    : self.product_id.uom_id.id,
        #                                     'ref'               : self.name,
        #                                     'width'             : hasil[0],
        #                                     'weight'            : hasil[1]})

        #     sql = 'UPDATE sletting_order_hasil SET lot_id = %s \
        #                  WHERE sletting_id = %s AND width = %s AND weight = %s' % (lot_id.id,self.id,hasil[0],hasil[1])
        #     self._cr.execute (sql)

        #     product_akhir = {'location_id'      : self.product_id.property_stock_inventory.id,
        #                     'location_dest_id'  : self.location_dest_id.id,
        #                     'product_uom_qty'   : hasil[2],
        #                     'product_uom'       : self.uom_id.id,
        #                     'width'             : hasil[0],
        #                     'weight'            : hasil[1],
        #                     'restrict_lot_id'   : lot_id.id}
            
        #     data2.update(product_akhir)
        #     # create move raw dari virtual
        #     move2 = move_obj.sudo().create(data2)
        #     move2.filtered(lambda move: move.state != 'done').action_done()

    @api.multi
    def action_mark_done(self):
        lot_obj = self.env['stock.production.lot']
        move_obj = self.env['stock.move']
        quant_obj = self.env['stock.quant']
        loc_obj = self.env['stock.location']
        if not self.hasil_ids :
            raise UserError(_('Hasil sletting tidak boleh kosong !'))

        datas = self._generate_moves_param()
        data2 = datas
        for hasil in self.hasil_ids:
            if hasil.width <= 0.0 and hasil.weight <= 0.0 :
                hasil.unlink()
                continue
            new_name = self.name + '01'
            old_name = self.name+'%'
            # cek sequence sebelumnya
            self._cr.execute("SELECT name FROM stock_production_lot " \
                                "WHERE name like %s ORDER BY name DESC limit 1" , (old_name ,))
            exist      = self._cr.fetchone()
            if exist :
                seq = str(exist[0])[-2:]
                new_seq = "%02d" % (int(int(seq)+1))
                new_name = self.name + str(new_seq)
            data_lot = {'product_id'        : self.product_id2.id,
                        'product_uom_id'    : self.product_id2.uom_id.id,
                        'name'              : new_name,
                        'ref'               : self.name}
            if hasil.width > 0.0 :
                data_lot.update({'width'    : str(hasil.width)+' mm'})
            if hasil.weight > 0.0 :
                data_lot.update({'weight'   : str(hasil.weight)+' Kg'})
                
            lot_id = lot_obj.sudo().create(data_lot)
            #import pdb;pdb.set_trace()
            hasil.write({'lot_id':lot_id.id})

            product_akhir = {'product_id'       : self.product_id2.id,
                             'product_uom'      : self.product_id2.uom_id.id,
                            'location_id'       : self.product_id.property_stock_production.id,
                            'location_dest_id'  : self.location_dest_id.id,
                            'product_uom_qty'   : hasil.weight,
                            'product_uom'       : self.product_uom_id.id,
                            'restrict_lot_id'   : lot_id.id}
            
            data2.update(product_akhir)
            # create move raw dari virtual
            move2 = move_obj.sudo().create(data2)
            move2.filtered(lambda move: move.state != 'done').action_done()
            lot_id.product_qty

        return self.write({'state': 'done'})

    @api.multi
    def action_cancel(self):
        if self.state == 'confirm':
            move_obj = self.env['stock.move']
            datas = self._generate_moves_param()
            data3 = datas

            product_cancel = {'location_id'         : self.product_id.property_stock_production.id,
                                'location_dest_id'  : self.location_src_id.id,
                                'product_uom_qty'   : self.product_qty,
                                'product_uom'       : self.product_uom_id.id,
                                'restrict_lot_id'   : self.lot_id.id}

            data3.update(product_cancel)
            # create move raw dari virtual
            move3 = move_obj.sudo().create(data3)
            move3.filtered(lambda move: move.state != 'done').action_done()

            return self.write({'state': 'cancel'})
            self.lot_id.product_qty
            
        elif self.state == 'draft':
            return self.write({'state': 'cancel'})

    @api.multi
    def action_audited(self):
        return self.write({'state': 'audit'})

    @api.multi
    def button_scrap(self):
        self.ensure_one()
        return {
            'name': _('Scrap'),
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'stock.scrap',
            'view_id': self.env.ref('stock.stock_scrap_form_view').id,
            'type': 'ir.actions.act_window',
            'context': {'default_sletting_id': self.id,'product_ids': self.product_id.id,'default_origin': self.name},
            # 'context': {'product_ids': self.move_raw_ids.filtered(lambda x: x.state not in ('done', 'cancel')).mapped('product_id').ids + [self.production_id.product_id.id]},
            'target': 'new',
        }

    @api.multi
    def action_see_move_scrap(self):
        self.ensure_one()
        action = self.env.ref('stock.action_stock_scrap').read()[0]
        action['domain'] = [('sletting_id', '=', self.id)]
        return action

    def _generate_moves_param(self):
        value = {
            'name': _('Sletting : ') + (self.name or ''),
            'origin': self.name,
            'product_id': self.product_id.id,
            'product_uom': self.product_id.uom_id.id,
            'date': self.schedule_date,
            'company_id': self.user_id.company_id.id,
            'state': 'confirmed',
            'restrict_lot_id': self.lot_id.id}
        return value

class SlettingOrderHasil(models.Model):
    _name = "sletting.order.hasil"

    @api.model
    def default_get(self, default_fields):
        res = {}
        if self._context:
            context_keys = self._context.keys()
            next_sequence = 1
            if 'hasil_ids' in context_keys:
                if len(self._context.get('hasil_ids')) > 0:
                    next_sequence = len(self._context.get('hasil_ids')) + 1
            res.update({'sequence': next_sequence})
        return res

    sletting_id = fields.Many2one('sletting.order',string='Sletting', ondelete='cascade')
    lot_id = fields.Many2one('stock.production.lot',string='Lot')
    sequence = fields.Integer('Gulungan Ke-')
    width = fields.Float('Lebar (mm)')
    weight = fields.Float('Berat (Kg)')