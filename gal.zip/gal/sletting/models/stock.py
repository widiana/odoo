# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2017  widianajuniar@gmail.com
#    All Rights Reserved.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import api, fields, models


class StockScrap(models.Model):
    _inherit = 'stock.scrap'

    sletting_id = fields.Many2one(
        'sletting.order', 'Sletting',
        states={'done': [('readonly', True)]})
    note = fields.Text('Notes')

StockScrap()


class StockProductionLot(models.Model):
    _inherit = 'stock.production.lot'

    @api.model
    def name_search(self, name, args=None, operator='ilike', limit=100):
        args = args or []
        domain = []
        if name:
            domain = ['|','|', ('name', operator, name), ('width', operator, name), ('weight', operator, name)]
        pos = self.search(domain + args, limit=limit)
        return pos.name_get()

    @api.multi
    @api.depends('name', 'width', 'weight')
    def name_get(self):
        result = []
        for lot in self:
            name = lot.name
            if lot.width :
                name = name + ' (' + lot.width +' )'
            if lot.weight :
                name = name + ' (' + lot.weight +' )'
            result.append((lot.id, name))
        return result

    product_qty_store = fields.Float('Quantity Store')
    product_qty = fields.Float('Quantity', compute='_product_qty',readonly=True)
    # sletting_id = fields.Many2one('sletting.order',string='Sletting')
    width = fields.Char('Lebar (mm)')
    weight = fields.Char('Berat (Kg)')

    @api.one
    @api.depends('quant_ids.qty')
    def _product_qty(self):
        loc_ids = self.quant_ids.filtered(lambda x: x.location_id.usage == 'internal').mapped('qty')
        self.product_qty = sum(self.quant_ids.mapped('qty'))
        self.write({'product_qty_store': sum(loc_ids)})

StockProductionLot()

class PackOperationLot(models.Model):
    _inherit = "stock.pack.operation.lot"

    internal_code = fields.Char('Internal Code')


class Picking(models.Model):
    _inherit = "stock.picking"
    
    def _create_lots_for_picking(self):
        Lot = self.env['stock.production.lot']
        for pack_op_lot in self.mapped('pack_operation_ids').mapped('pack_lot_ids'):
            if not pack_op_lot.lot_id:
                lot = Lot.create({'name': pack_op_lot.lot_name, 'product_id': pack_op_lot.operation_id.product_id.id})
                if pack_op_lot.internal_code :
                    lot.update({'ref':pack_op_lot.internal_code})
                pack_op_lot.write({'lot_id': lot.id})
        # TDE FIXME: this should not be done here
        self.mapped('pack_operation_ids').mapped('pack_lot_ids').filtered(lambda op_lot: op_lot.qty == 0.0).unlink()
    create_lots_for_picking = _create_lots_for_picking