# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2017  widianajuniar@gmail.com
#    All Rights Reserved.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import api, fields, models, SUPERUSER_ID, _


class MRPWizard(models.TransientModel):
    _name = "mrp.production.wizard"

    item_ids = fields.One2many('mrp.production.items.wizard','item_id','Items')

    def _generate_moves(self):
        for production in self:
            factor = production.product_uom_id._compute_quantity(production.product_qty, production.bom_id.product_uom_id) / production.bom_id.product_qty
            boms, lines = production.bom_id.explode(production.product_id, factor, picking_type=production.bom_id.picking_type_id)
            production._generate_raw_moves(lines)
            # Check for all draft moves whether they are mto or not
            self._adjust_procure_method()
            self.move_raw_ids.action_confirm()
        return True

    @api.multi
    def fill_consumed_lines(self):
        #import pdb;pdb.set_trace() 
        production_id = self._context.get('active_id')
        if production_id :
            mrp_obj = self.env['mrp.production']
            production = mrp_obj.browse(production_id)
            quantity = 0
            if production.bom_id.routing_id and production.bom_id.routing_id.location_id:
                source_location = production.bom_id.routing_id.location_id
            else:
                source_location = production.location_src_id
            original_quantity = production.product_qty - production.qty_produced
            for mv in self.item_ids :
                data = {
                    'name': production.name,
                    'date': production.date_planned_start,
                    #'bom_line_id': bom_line.id,
                    'product_id': mv.product_id.id,
                    'product_uom_qty': quantity,
                    'product_uom': mv.product_id.uom_id.id,
                    'location_id': source_location.id,
                    'location_dest_id': production.product_id.property_stock_production.id,
                    'raw_material_production_id': production.id,
                    'company_id': production.company_id.id,
                    #'operation_id': bom_line.operation_id.id or alt_op,
                    'price_unit': mv.product_id.standard_price,
                    'procure_method': 'make_to_stock',
                    'origin': production.name,
                    'warehouse_id': source_location.get_warehouse().id,
                    'group_id': production.procurement_group_id.id,
                    'propagate': production.propagate,
                    'unit_factor': quantity / original_quantity,
                }
                move = self.env['stock.move'].create(data)
                move.action_confirm()
                lots = self.env['stock.production.lot'].sudo().search([('product_id','=',mv.product_id.id),('product_qty','>',0)])
                if lots :
                    for lot in lots :
                        lot.sudo().write({'product_qty_store':lot.product_qty})
            if self.item_ids :
                production._adjust_procure_method()
        return {'type': 'ir.actions.act_window_close'}

class MRPItemsWizard(models.TransientModel):
    _name = "mrp.production.items.wizard"

    item_id = fields.Many2one('mrp.production.wizard', string="Item")
    product_id = fields.Many2one('product.product', string="Product", required=True)

