# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2017  widianajuniar@gmail.com
#    All Rights Reserved.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import api, fields, models, SUPERUSER_ID, _


class MrpWorkorder(models.Model):
    _inherit = 'mrp.workorder'

    mesin_berhenti_ids = fields.One2many('mesin.berhenti','workorder_id',string='Laporan Mesin Berhenti',
        states={'done': [('readonly', True)], 'cancel': [('readonly', True)]},)
    sesuai = fields.Selection([('ya','Ya'),('tidak','Tidak')],'Sesuai ?',default='ya')
    ukuran = fields.Float('Ukuran', digits=(16, 2))
    standar_tebal = fields.Float('Standar Tebal', digits=(16, 2))
    sigmat = fields.Float('Sigmat', digits=(16, 2))
    panjang_real = fields.Float('Panjang Real', digits=(16, 2))
    panjang_kering = fields.Float('Panjang Kering', digits=(16, 2))
    standar_berat = fields.Float('Standar Berat', digits=(16, 2))
    standar_basah = fields.Float('Standar Basah', digits=(16, 2))
    berat_kering = fields.Float('Berat Kering', digits=(16, 2))
    qty = fields.Float('Qty', digits=(16, 2))
    bahan = fields.Float('Bahan (Kg)', digits=(16, 2))
    sampah = fields.Float('Sampah (Kg)', digits=(16, 2))
    pecent = fields.Float('%', digits=(16, 2))
    keterangan = fields.Float('Keterangan', digits=(16, 2))
    note = fields.Text('Notes')

class MesinBerhenti(models.Model):
    _name = 'mesin.berhenti'

    workorder_id = fields.Many2one('mrp.workorder',string='Work Order', ondelete='cascade')
    jam_stop = fields.Float(
        'Jam Berhenti', digits=(16, 2),
        help="Waktu Berhenti")
    jam_lapor = fields.Float(
        'Jam Lapor', digits=(16, 2),
        help="Waktu Lapor")
    penyebab_id = fields.Many2one('master.penyebab.mesin.berhenti','Penyebab')
    tindakan = fields.Char('Tindakan')
    jam_mulai_perbaikan = fields.Float(
        'Mulai Perbaikan', digits=(16, 2),
        help="Waktu Mulai Perbaikan Mesin)")
    jam_selesai_perbaikan = fields.Float(
        'Selesai Perbaikan', digits=(16, 2),
        help="Waktu Selesai Perbaikan Mesin") 
    durasi_perbaikan = fields.Float(
        'Durasi Perbaikan', digits=(16, 2),
        help="Durasi Perbaikan (in minutes)", compute='_durasi_perbaikan',store=True)  

    @api.one
    @api.depends('jam_mulai_perbaikan', 'jam_selesai_perbaikan')
    def _durasi_perbaikan(self):
        self.durasi_perbaikan = round(self.jam_selesai_perbaikan-self.jam_mulai_perbaikan,2)

class MasterPenyebabMesinBerhenti(models.Model):
    _name = 'master.penyebab.mesin.berhenti'

    name = fields.Char('Deskripsi',required=True, size=128)